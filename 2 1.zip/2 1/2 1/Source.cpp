#include <iostream> //library
using namespace std;

int main() //main function
{
	int x, y, total; //initialize variables
	x = 62; //give variables values
	y = 99;

	total = x + y; //give total the sum of x and y

	cout << total << endl; //shows total

	system("pause"); //leaves window up
	return 0;
}