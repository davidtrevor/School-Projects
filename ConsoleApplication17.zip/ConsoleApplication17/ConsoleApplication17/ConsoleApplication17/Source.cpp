#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	int choice;
	float feet;
	const int Air = 1100;
	const int Water = 4900; //initialize variables
	const int Steel = 16400;

	cout << "choose a medium" << endl << "1) Air" << endl << "2) Water" << endl << "3) Steel" << endl;
	cin >> choice;
	if (choice > 3 || choice < 1){ //validate choice
		cout << "input is invalid";
		return 0;
	}

	cout << "please enter the number of feet a sound wave will travel" << endl;
	cin >> feet;
	if (feet < 0){ //amount of feet
		cout << "input is invalid";
		return 0;
	}

	switch (choice){ //based on choice display answer
	case 1:
		cout << "in Air, sound traveling " << feet << " feet will take " << setprecision(4) << fixed << feet/Air << " seconds";
		break;
	case 2:
		cout << "in Water, sound traveling " << feet << " feet will take " << setprecision(4) << fixed << feet / Water << " seconds";
		break;
	case 3:
		cout << "in Steel, sound traveling " << feet << " feet will take " << setprecision(4) << fixed << feet / Steel << " seconds";
		break;
	}
	system("pause");
	return 0;
}