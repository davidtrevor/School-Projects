#include <iostream>
using namespace std;

class Example {
private:
	int myValue;
	int mySecondValue;
public:
	Example(const int &);
	Example(const int &, const int &);
	//A friend function is used so the private member variables are accessible
	friend int getMyValue(const Example&);
	friend void deleteValues(Example myObj);
	friend int addValues(const Example&);
	friend void printValues(const Example myObj);
};

Example::Example(const int & value) : myValue(value), mySecondValue(0) {} //constructors
Example::Example(const int & value, const int & value2) : myValue(value), mySecondValue(value2) {}

int getMyValue(const Example& obj) { //functions
	return obj.myValue;
}
int addValues(const Example& obj) {
	return obj.myValue + obj.mySecondValue;
}
void printValues(Example myObj) {
	cout << myObj.myValue << endl;
	cout << myObj.mySecondValue << endl;
}
void deleteValues(Example myObj) {
	myObj.myValue = 0;
	myObj.mySecondValue = 0;
}


int main() {

	Example myObj(10);

	Example myObj(10, 100);

	//Calling friend function to get the private member variable of myValue
	cout << getMyValue(myObj);

	cout << "\n\n";
	system("pause");
	return 0;
}
