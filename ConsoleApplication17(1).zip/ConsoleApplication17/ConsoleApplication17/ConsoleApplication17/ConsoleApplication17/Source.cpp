#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	int sum = 0;
	int choice = -5;
	while (choice < 1){     //loop continues until a positive integer is entered
		cout << "please enter a positive integer" << endl;
		cin >> choice;}
	for (int n = choice; n > 0; n--) {}
	while (choice > 0){   //each time the loop runs it adds the current count and then counts down until it reaches 0
		sum = sum + choice;
		choice = choice - 1;}
	cout << sum << endl;
	system("PAUSE");
	return 0;
}