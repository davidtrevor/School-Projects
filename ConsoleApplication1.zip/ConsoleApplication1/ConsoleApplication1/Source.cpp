#include <iostream>
#include <fstream>
using namespace std;
int main() {
	ifstream inputFile; //create input stream
	int year = 1910, pop; //initialize variables
	inputFile.open("People.txt"); //open the file/input stream
	while (inputFile >> pop) {		//run as long as file hasn't ended
		cout << endl << year << ": ";	//show year
		while (pop > 0) {	//show * for every 1000
			cout << "*";
			pop = pop - 1000;
		}
		year = year + 20; //increase year
	}
}