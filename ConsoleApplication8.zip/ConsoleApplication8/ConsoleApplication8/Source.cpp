#include <iostream>
using namespace std;

class Circle {
	int itemNumber;
	int quantity;
	double radius;

public:
	Circle();
	~Circle();

	void setRadius(double);

	double getRadius();

	bool operator >(const Circle& rhs) {
		

		if (radius > rhs.radius)
			return true;
		else
			return false;
	}
	
	double calc(double);
};

void Circle::setRadius(double x) {        //set functions
	radius = x;
}
double Circle::getRadius() {           //get functions
	return radius;
}
Circle::Circle()         //default constructor
{
	radius = 0;
}
Circle::~Circle()      {
	cout << "object is deleted" << endl;
}

double Circle::calc(double radius) {             //calc 
	return radius * 3.14 * radius;
}



int main() {
	Circle hold[5];
	int i = 0;
	int value = 0;

	while (i < 5) {
		cout << "please enter a radius" << endl;
		cin >> value;
		hold[i].setRadius(value);
		i++;
	}
	int largest = 0;
	int b = 1;
	while (b < 5) {
		if (hold[b] > hold[largest]) {
			largest = b;
		}
		b++;
	}
	double fina = hold[largest].getRadius();
	cout << hold[largest].calc(fina) << endl;
	//cout << largest << endl;
	//cout << fina;
	system("pause");
	return 0;
}