#include <iostream>
#include <iomanip>
using namespace std;

int main(){
	int speed = 0;
	int hours = 0;
	cout << "what is the speed of the vehicle" << endl; //take in user values
	cin >> speed;
	cout << endl << "what is the number of hours" << endl;
	cin >> hours;

	cout << endl << setw(1) << "hours";  //create top of the table
	cout << setw(18) << "miles traveled" << endl;
	cout << "------------------------------" << endl << endl;

	for (int counter = 1; counter < hours + 1; counter = counter + 1){   //loop, cout hour and miles traveled each time until reaching final hour
		cout << setw(1) << counter;
		cout << setw(10) << counter*speed << endl;
	}
}
