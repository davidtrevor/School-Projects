#include <iostream>
#include <iomanip>
using namespace std;

double celcius(double degree);

int main() {
	int number = 0;

	cout << left << "farenheight";
	cout << setw(9) << right << "celcius" << endl;
	cout << "----------------" << endl;
	while (number < 21) {
		cout << left << number;
		cout << setw(19) << right << fixed << setprecision(4) << celcius(number) << endl;
		number++;
	}
	return 0;
}

double celcius(double degree) {
	double temp = (degree - 32) * 5 / 9;
	return temp;
}