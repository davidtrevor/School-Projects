#include <iostream>
using namespace std;

class Example {
	int itemNumber;
	int quantity;
	double cost;

public:
	Example();

	Example(double, int, int);

	void setCost(double);
	void setQuantity(int);
	void setItemNumber(int);

	double getCost();
	int getQuantity();
	int getItemNumber();

	double calc(double, int);
};

void Example::setCost(double x) {        //set functions
	cost = x;
}
void Example::setQuantity(int x) {
	quantity = x;
}
void Example::setItemNumber(int x) {
	itemNumber = x;
}
double Example::getCost() {           //get functions
	return cost;
}
int Example::getQuantity() {
	return quantity;
}
int Example::getItemNumber() {
	return itemNumber;
}
Example::Example()         //default constructor
{
	cost = 0;
	quantity = 0;
	itemNumber = 0;
}
Example::Example(double a, int b, int c)        //constructor
{
	cost = a;
	quantity = b;
	itemNumber = c;
}
double Example::calc(double a, int b) {             //calc total cost
	return quantity * cost;
}
int main() {
	system("pause");
	return 0; }