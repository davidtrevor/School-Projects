#include <iostream>
using namespace std;

int countPerfect(int[]); //prototype

int main() {
	int store[5] = { 101, 101, 101, 101, 101 };
	int x = 0;
	while (x < 5) {
		while (store[x] > 100 || store[x] < 0) { //entering in numbers to the array
			cout << "please enter a number between 0 and 100" << endl;
			cin >> store[x];
		}
			x++;
	}
	x = 0;
	cout << endl << endl << "showing array values" << endl;
	while (x < 5) { //printing array purely for my knowledge
		cout << store[x] << endl;
		x++;
	}
	cout << endl << endl << countPerfect(store) << " perfect scores" << endl; // printing perfect scores
	system("PAUSE");
	return 0;
}

int countPerfect(int store[]) {
	int y = 0;
	int counter = 0;
	while (y < 5) { //going through array and checking perfect scores
		if (store[y] == 100) {
			counter++;
		}
		y++;
	}
	return counter;
}