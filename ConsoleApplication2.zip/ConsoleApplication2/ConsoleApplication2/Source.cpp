#include <iostream> //library
using namespace std;

int main() //main function
{
	double paid;
	double shares = 600;
	double price = 21.77;
	double x;

	paid = price * shares;
	cout << "total amount paid " << paid << endl;
	price = 16.44;
	x = price * shares;
	cout << "total amount recieved " << x << endl;
	cout << "total lost " << paid - x << endl;

	system("pause"); //leaves window up
	return 0;
}