#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

double fallingDistance(double number);

int main() {
	int number = 0;

	cout << left << "seconds";
	cout << setw(9) << right << "distance" << endl; //headers
	cout << "----------------" << endl;
	while (number < 11) { //loop to show time and call distance function
		cout << left << number;
		cout << setw(13) << right << fixed << setprecision(1) << fallingDistance(number) << endl;
		number++;
	}
	system("PAUSE");
	return 0;
}

double fallingDistance(double number) {
	const double G = 9.8;
	double temp = .5 * G * pow(number, 2); //equation
	return temp;
}