#include <iostream> //library
using namespace std;

int main() //main function
{
	double tip, bill, taxTotal, total; //initialize variables
	const double TAX = .0675; //give variables initial values
	tip = 0;
	bill = 44.5;
	total = 0;

	tip = .15 * bill; //calculate tip and tax
	taxTotal = TAX * bill;
	total = taxTotal + tip + bill;  //give total the sum of everything

	cout << "total " << total << endl; //shows total
	cout << "bill " << bill << endl; //shows total
	cout << "tip " << tip << endl; //shows total
	cout << "tax " << taxTotal << endl; //shows total

	system("pause"); //leaves window up
	return 0;
}