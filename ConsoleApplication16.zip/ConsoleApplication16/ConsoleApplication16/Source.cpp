#include <iostream>
using namespace std;
int main()
{
	float num1, num2, num3, num4 = 0;
	cout << "Please enter the length and width for rectangle 1" << endl << "seperate your values using a space:" << endl;
	cin >> num1;
	cin >> num2;

	cout << endl << endl << " please enter the values for rectangle 2:";
	cin >> num3;
	cin >> num4;

	cout << endl << endl << "Rectangle 1 has an area of " << num1*num2 << endl << "Rectangle 2 has an area of " << num3*num4 << endl;

	if (num1*num2 > num3*num4)
		cout << "rectangle 1 is larger";
	else 
		cout << "rectangle 2 is larger";
}