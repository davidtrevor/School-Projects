#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void main(){

	double rate, principal, interest;
	rate = 0;
	int times = 0; //initialize variables
	principal = 0;
	interest = 0;
	double final = 0;
	double amount = 0;

	cout << "please enter the interest rate "; //explain to user and accept input for variables
	cin >> rate;
	cout << "please enter the principal ";
	cin >> principal;
	cout << "please enter the number of times interest is compounded ";
	cin >> times;

	final = principal * pow((1 + rate / times),times);  //do calculations
	interest = final - principal;

	cout << left << "interest rate" << right << rate << endl;
	cout << left << setw(20) << fixed << setprecision(2) << "times compounded" << right << times << endl;  //cout values alligned and with correct decimal places
	cout << left << setw(20) << fixed << setprecision(2) << "Principal" << right << principal << endl;
	cout << left << setw(20) << fixed << setprecision(2) << "interest" << right << interest << endl;
	cout << left << setw(20) << fixed << setprecision(2) << "final balance" << right << final;





	system("pause");







}